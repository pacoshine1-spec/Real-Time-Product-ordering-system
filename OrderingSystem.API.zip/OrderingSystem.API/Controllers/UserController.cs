using Microsoft.AspNetCore.Mvc;
using OrderingSystem.API.Models;

namespace OrderingSystem.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        // TEMP DATABASE
        private static List<User> users = new List<User>
        {
            new User { Id = 1, Username = "admin", Password = "1234" }
        };

        // =========================
        // GET ALL USERS
        // =========================
        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(users);
        }

        // =========================
        // CREATE USER (POST)
        // =========================
        [HttpPost]
        public IActionResult Add(User user)
        {
            user.Id = users.Count + 1;
            users.Add(user);

            return Ok(user);
        }

        // =========================
        // UPDATE USER (PUT)
        // =========================
        [HttpPut("{id}")]
        public IActionResult Update(int id, User updated)
        {
            var user = users.FirstOrDefault(u => u.Id == id);
            if (user == null) return NotFound();

            user.Username = updated.Username;
            user.Password = updated.Password;

            return Ok(user);
        }

        // =========================
        // DELETE USER
        // =========================
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var user = users.FirstOrDefault(u => u.Id == id);
            if (user == null) return NotFound();

            users.Remove(user);

            return Ok("User deleted successfully");
        }
    }
}